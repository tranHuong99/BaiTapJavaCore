/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.act.showcase.model;

import com.act.showcase.db.DBConnector;
import com.act.showcase.dto.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pc
 */
public class ProductModel {

    public List<Product> getAll() throws ClassNotFoundException, SQLException {
        ArrayList<Product> list = new ArrayList<>();
        
        Connection conn = new DBConnector().getConnect();
        String sql = "SELECT * FROM products";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            Product p = new Product();
            p.setId(rs.getInt("id"));
            p.setName(rs.getString("name"));
            p.setDescription(rs.getString("description"));
            p.setImages(rs.getString("images"));
           // .....
            list.add(p);
        }
        return list;
    }
}
